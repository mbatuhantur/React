const AboutPage = () => {
  return (
    <div className="about-page">
      <h1>About Page</h1>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati
        explicabo necessitatibus cupiditate deserunt tempore natus soluta fugit
        odit repellendus libero perferendis, ipsa fugiat maiores quam excepturi
        cum incidunt veritatis facilis inventore iusto! Facere exercitationem
        nobis nam asperiores voluptatibus delectus vitae animi neque natus
        expedita facilis eius recusandae consequatur, aliquid ut obcaecati. Eos,
        doloremque pariatur quas laudantium corporis quo dolores distinctio,
        tenetur laboriosam recusandae culpa, dolorem officiis. Placeat
        temporibus aliquid amet eum facilis exercitationem accusantium corrupti
        unde velit. Nemo, incidunt atque!
      </p>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati
        explicabo necessitatibus cupiditate deserunt tempore natus soluta fugit
        odit repellendus libero perferendis, ipsa fugiat maiores quam excepturi
        cum incidunt veritatis facilis inventore iusto! Facere exercitationem
        nobis nam asperiores voluptatibus delectus vitae animi neque natus
        expedita facilis eius recusandae consequatur, aliquid ut obcaecati. Eos,
        doloremque pariatur quas laudantium corporis quo dolores distinctio,
        tenetur laboriosam recusandae culpa, dolorem officiis. Placeat
        temporibus aliquid amet eum facilis exercitationem accusantium corrupti
        unde velit. Nemo, incidunt atque!
      </p>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati
        explicabo necessitatibus cupiditate deserunt tempore natus soluta fugit
        odit repellendus libero perferendis, ipsa fugiat maiores quam excepturi
        cum incidunt veritatis facilis inventore iusto! Facere exercitationem
        nobis nam asperiores voluptatibus delectus vitae animi neque natus
        expedita facilis eius recusandae consequatur, aliquid ut obcaecati. Eos,
        doloremque pariatur quas laudantium corporis quo dolores distinctio,
        tenetur laboriosam recusandae culpa, dolorem officiis. Placeat
        temporibus aliquid amet eum facilis exercitationem accusantium corrupti
        unde velit. Nemo, incidunt atque!
      </p>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati
        explicabo necessitatibus cupiditate deserunt tempore natus soluta fugit
        odit repellendus libero perferendis, ipsa fugiat maiores quam excepturi
        cum incidunt veritatis facilis inventore iusto! Facere exercitationem
        nobis nam asperiores voluptatibus delectus vitae animi neque natus
        expedita facilis eius recusandae consequatur, aliquid ut obcaecati. Eos,
        doloremque pariatur quas laudantium corporis quo dolores distinctio,
        tenetur laboriosam recusandae culpa, dolorem officiis. Placeat
        temporibus aliquid amet eum facilis exercitationem accusantium corrupti
        unde velit. Nemo, incidunt atque!
      </p>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati
        explicabo necessitatibus cupiditate deserunt tempore natus soluta fugit
        odit repellendus libero perferendis, ipsa fugiat maiores quam excepturi
        cum incidunt veritatis facilis inventore iusto! Facere exercitationem
        nobis nam asperiores voluptatibus delectus vitae animi neque natus
        expedita facilis eius recusandae consequatur, aliquid ut obcaecati. Eos,
        doloremque pariatur quas laudantium corporis quo dolores distinctio,
        tenetur laboriosam recusandae culpa, dolorem officiis. Placeat
        temporibus aliquid amet eum facilis exercitationem accusantium corrupti
        unde velit. Nemo, incidunt atque!
      </p>
    </div>
  );
};

export default AboutPage;
