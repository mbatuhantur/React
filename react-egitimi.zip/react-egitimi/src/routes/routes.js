import { adminRoutes } from "./AdminRoutes";
import { mainRoutes } from "./MainRoutes";

export { mainRoutes, adminRoutes };
